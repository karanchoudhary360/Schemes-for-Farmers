package com.lti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmEasy4Application {

	public static void main(String[] args) {
		SpringApplication.run(FarmEasy4Application.class, args);
	}

}
