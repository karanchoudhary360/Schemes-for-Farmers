package com.lti.layer4.service;

import com.lti.layer2.entity.InsuranceDetail;

public interface InsuranceService {
	
	
	void addInsuranceService(InsuranceDetail insureDet);

}
