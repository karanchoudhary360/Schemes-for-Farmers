export class LiveBidsForBidder{
sellId: number;
cropName:string;
basePrice:number;
bidderAmt:number;
}