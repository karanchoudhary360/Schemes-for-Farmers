import { AddressDetail } from "src/AddressDetail";
import { BankDetail } from "src/BankDetail";


export class FarmerDetail
	{

	  farmerEmail:string;

	  aadharNumber:string;

	  contactNum:string;

	  farmerName :string;
	
	  pancardNumber :string;
    
	  password: string;

	  soilPhCert: string;
	    
	  addressDetail: AddressDetail;
	 
      bankDetail: BankDetail;
      
 


	}