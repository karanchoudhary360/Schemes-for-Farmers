import { AddressDetail } from "./AddressDetail";
import { BankDetail } from "./BankDetail";

export class FarmerDetail
	{

	  farmerEmail:string;

	  aadharNumber:string;

	  contactNum:string;

	  farmerName :string;
	
	  pancardNumber :string;
    
	  password: string;

	  soilPhCert: string;
	    
	  addressDetail: AddressDetail;
	 
      bankDetail: BankDetail;
      
 


	}