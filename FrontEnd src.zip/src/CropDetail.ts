export class CropDetail{    

    cropName:String;
  
   cropType:String;
  
    msp: number;
  
  }